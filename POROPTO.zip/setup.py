from setuptools import setup, find_packages
from os import path

# Get the current directory where setup.py is located
working_directory = path.abspath(path.dirname(__file__))

# Read the content of your README.md file for the long description
with open(path.join(working_directory, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

setup(
    name='POROPTO',
    version='0.0.1',
    author='Nazanin Ghaemi-Zadeh',
    author_email='nghz.sut@gmail.com',
    description='Portfolio Optimization in Python',
    long_description=long_description,
    long_description_content_type='text/markdown',  # Set the format of the long description
    url='https://github.com/nazanin-ghaemizadeh',
    packages=find_packages(),  # Automatically discover all packages
    install_requires=[],  # Add required packages here, e.g., 'numpy', 'pandas', etc.
)
